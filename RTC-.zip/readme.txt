Readme file for DS1307RTC Library

The DS1307RTC library is provided to demonstrate the Arduino Time library.

See the TimeRTC example sketches privided with the Time library download for usage

Due to the dependency of another Time library, those files are included here with it.

Tested with DS1307 and DS3231 RTC module and Arduino Uno and Mega


